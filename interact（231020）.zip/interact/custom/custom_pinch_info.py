# -*- encoding:utf-8 -*-
_reload_all = True


data = {'f': [('', 0, 2147483647, 'code_explorer_custom_root_folder_name')], 'd': {}}